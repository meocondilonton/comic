Hello. Discussion on my code is welcome.

This game has been successfully compiled on Mac OS X.
Windows and Fedora Linux testers/scripts wanted...


Screen shots:
=============
![alt text](https://raw.github.com/davehorner/KM-Bubble-Shooter/master/screencaps/bubbleshooter.jpg "main screen")
![alt text](https://raw.github.com/davehorner/KM-Bubble-Shooter/master/screencaps/bubbleshooter_highscore.jpg "high score")
![alt text](https://raw.github.com/davehorner/KM-Bubble-Shooter/master/screencaps/bubbleshooter_newgame.jpg "newgame")

Installation:
=============

### Mac ###

    $ brew install libvorbis sdl sdl_ttf sdl_mixer sdl_gfx sdl_image
    $ make
    $ ./km-bubble-shooter
    $ # party
